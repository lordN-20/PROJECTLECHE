<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "students");
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
$conn = mysqli_connect("localhost", "root", "", "students");
if ($result = mysqli_query($conn, "SELECT * FROM students WHERE role != 'admin'")) {
    $row = $result->fetch_assoc();
    if($section== $row["section"]){
        mysqli_close($link);     
    } else {
        echo "0 results";
    }
}
// Close connection
mysqli_close($link);



 ?>