<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "students");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security

$username = mysqli_real_escape_string($link, $_REQUEST['username']);
$ID = mysqli_real_escape_string($link, $_REQUEST['ID']);
$Address = mysqli_real_escape_string($link, $_REQUEST['Address']);
$Email = mysqli_real_escape_string($link, $_REQUEST['Email']);
$pass = mysqli_real_escape_string($link, $_REQUEST['pass']);
$section = mysqli_real_escape_string($link, $_REQUEST['section']);
 
// Attempt insert query execution
$sql = "INSERT INTO student (id, name, section, address, email, password, role) VALUES ('$ID', '$username', '$section','$Address', '$Email', '$pass', 'student')";
if(mysqli_query($link, $sql)){
    header('Location: ../view/nextpage.html');
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>