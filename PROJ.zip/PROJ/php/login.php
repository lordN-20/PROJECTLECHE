<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "students");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security

$Email = mysqli_real_escape_string($link, $_REQUEST['Email']);
$pass = mysqli_real_escape_string($link, $_REQUEST['pass']);
 
// Attempt insert query execution
$sql = "SELECT * FROM student WHERE email = '".$Email."'";
//echo $sql;
$result = mysqli_query($link, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
       
        if($pass == $row["password"]){
            if($row["role"] == "admin"){
                session_start();
                $_SESSION['isLoggedIn'] = true;
                header("Location:../php/admin.php");
            }else{
                $error = "";
                session_start();
                $_SESSION['studentID'] = $row["id"];
                header("Location:../php /study.php");
            }
            
        }
        else{
            $_SESSION['incPw'] = 'Incorrect Password';
        }

    }
} else {
    echo "0 results";
}
 
// Close connection
mysqli_close($link);
?>