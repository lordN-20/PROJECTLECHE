<?php
include_once 'database.php';

try
{
     $database = new Connection();
     $db = $database->openConnection();
     $sql = "CREATE TABLE `Student` ( `id` INT NOT NULL AUTO_INCREMENT , `name`VARCHAR(40) NOT NULL , `section`VARCHAR(40) NOT NULL, `address` VARCHAR(40) NOT NULL , `email` VARCHAR(40)NOT NULL , `password` VARCHAR(40)NOT NULL, PRIMARY KEY (`id`)) ";
     $db->exec($sql);
     echo "Table Student created successfully";
     $database->closeConnection();
}
catch (PDOException $e)
{
    echo "There is some problem in connection: " . $e->getMessage();
}
?>